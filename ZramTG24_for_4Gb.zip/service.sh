#!/system/bin/sh

su -c '
swapoff /dev/block/zram0 2>/dev/null
echo 1 > /sys/block/zram0/reset
echo lz4 > /sys/block/zram0/comp_algorithm
echo 2G > /sys/block/zram0/disksize
echo 100 > /proc/sys/vm/swappiness
echo 150 > /proc/sys/vm/vfs_cache_pressure
echo 0 > /proc/sys/vm/page-cluster
echo 0 > /sys/block/mmcblk0/queue/iostats 2>/dev/null
echo 256000 > /proc/sys/vm/min_free_kbytes
echo 0 > /proc/sys/vm/dirty_expire_centisecs
echo 500 > /proc/sys/vm/dirty_writeback_centisecs
echo "performance" > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor
echo "performance" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
echo 1 > /proc/sys/kernel/sched_child_runs_first
echo 10000000 > /proc/sys/kernel/sched_latency_ns
echo 2000000 > /proc/sys/kernel/sched_wakeup_granularity_ns
echo 500000 > /proc/sys/kernel/sched_migration_cost_ns
echo 100 > /proc/sys/kernel/sched_util_clamp_max
echo 80 > /proc/sys/kernel/sched_util_clamp_min
mkswap /dev/block/zram0 >/dev/null 2>&1
swapon /dev/block/zram0 -p 100

SWAP_PATH="/data/local/tmp/swapfile"

if [ ! -f "$SWAP_PATH" ]; then
    echo "Criando Swapfile... aguarde."
    fallocate -l 2G "$SWAP_PATH" || dd if=/dev/zero of="$SWAP_PATH" bs=1M count=2048
    chmod 600 "$SWAP_PATH"
    mkswap "$SWAP_PATH"
fi

if grep -q "swapfile" /proc/swaps; then
    echo "Status: Swapfile já está ativo. Pulando..."
else
    swapon "$SWAP_PATH" -p 5
    echo "Status: Swapfile ativado agora."

fi

for i in /sys/block/mmcblk*/queue/read_ahead_kb; do
	echo 4096 > $i;
done

for i in /sys/block/mmcblk*/queue/scheduler; do
    echo "mq-deadline" > $i || echo "deadline" > $i
done

for i in /sys/block/mmcblk*/queue/iostats; do
    echo 0 > $i
done

sync
echo 3 > /proc/sys/vm/drop_caches
echo "------------------------------------------"
echo "  COMBO DE PERFORMANCE ATIVADO - 4GB TOTAL"
echo "------------------------------------------"
cat /proc/swaps
'
